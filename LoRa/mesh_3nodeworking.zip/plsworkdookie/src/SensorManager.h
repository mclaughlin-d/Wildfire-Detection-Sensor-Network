#pragma once

#include <Arduino.h>

/**
 * @file SensorManager.h
 * @brief Receives the 214-byte msgPayload struct from the STM32 over UART
 *        and exposes it for transmission via MeshNode::sendSensorPacket().
 *
 * The STM32 owns all sensor reading (thermal camera, gas sensors, etc.) and
 * sends a complete msgPayload struct over hardware UART whenever new data is
 * ready. This class just buffers that incoming data.
 *
 * WIRING (adjust pins to match your RAK4631 UART assignment):
 *   RAK4631 RX  <-->  STM32 TX
 *   RAK4631 TX  <-->  STM32 RX   (optional, for ack/handshake)
 *   GND         <-->  GND
 *
 * Set STM32_SERIAL below to whichever HardwareSerial port you wired up.
 * Default baud rate matches whatever you set on the STM32 side.
 */

// ── Configuration ──────────────────────────────────────────────────────────
// Change these to match your hardware wiring.
#define STM32_SERIAL  Serial1   // Hardware serial connected to STM32
#define STM32_BAUD    115200

// Must match sizeof(msgPayload) on the STM32.
// Verified: 214 bytes.
#define MSG_PAYLOAD_SIZE 214
// ───────────────────────────────────────────────────────────────────────────

class SensorManager {
public:
    SensorManager() : _dataReady(false), _bytesReceived(0) {
        memset(_buf, 0, sizeof(_buf));
    }

    /**
     * @brief Call once in setup(). Opens the UART to the STM32.
     */
    void begin() {
        STM32_SERIAL.begin(STM32_BAUD);
        Serial.println("SensorManager: UART to STM32 open @ " + String(STM32_BAUD));
    }

    /**
     * @brief Call every loop iteration.
     *        Accumulates incoming bytes until a full msgPayload has arrived,
     *        then sets the data-ready flag.
     *
     * Protocol: STM32 sends exactly MSG_PAYLOAD_SIZE bytes back-to-back,
     * then waits for the next send interval. No framing bytes needed because
     * the size is fixed and both sides reset together on power-up.
     *
     * If you later want a start-byte or length prefix for robustness, add it
     * here and mirror it on the STM32 side.
     */
    void update() {
        while (STM32_SERIAL.available() && _bytesReceived < MSG_PAYLOAD_SIZE) {
            _buf[_bytesReceived++] = (uint8_t)STM32_SERIAL.read();
        }

        if (_bytesReceived >= MSG_PAYLOAD_SIZE) {
            _dataReady      = true;
            _bytesReceived  = 0;  // reset for next frame
        }
    }

    /**
     * @brief Returns true if a complete msgPayload is waiting to be sent.
     */
    bool isDataReady() const { return _dataReady; }

    /**
     * @brief Copies the buffered payload into the caller's buffer.
     * @param outBuf  Destination buffer — must be at least MSG_PAYLOAD_SIZE bytes.
     * @param maxLen  Size of outBuf.
     * @return Number of bytes copied, or 0 on error.
     *
     * Clears the data-ready flag after copying so the same frame isn't sent twice.
     */
    size_t getPayload(uint8_t* outBuf, size_t maxLen) {
        if (!_dataReady || !outBuf || maxLen < MSG_PAYLOAD_SIZE) return 0;
        memcpy(outBuf, _buf, MSG_PAYLOAD_SIZE);
        _dataReady = false;
        return MSG_PAYLOAD_SIZE;
    }

    /**
     * @brief Debug helper: prints the raw payload as hex over USB serial.
     */
    void printPayloadHex(const uint8_t* buf, size_t len) {
        Serial.print("SensorManager payload [");
        Serial.print(len);
        Serial.print(" bytes]: ");
        for (size_t i = 0; i < len; i++) {
            if (buf[i] < 0x10) Serial.print('0');
            Serial.print(buf[i], HEX);
            Serial.print(' ');
            if ((i + 1) % 16 == 0) Serial.println();
        }
        Serial.println();
    }

private:
    bool    _dataReady;
    size_t  _bytesReceived;
    uint8_t _buf[MSG_PAYLOAD_SIZE];
};
