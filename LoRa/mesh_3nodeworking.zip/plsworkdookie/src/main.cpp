/**
 * @file main.cpp
 * @brief Wildfire Detection Mesh Node — RAK4631
 *
 * Adapted from prior group's LoRa mesh codebase.
 * Changes from original:
 *   - SensorManager now reads 214-byte msgPayload from STM32 over UART
 *   - MeshPacket MAX_PAYLOAD bumped to 220 (fits 214-byte struct)
 *   - OLEDDisplay replaced with a no-op stub
 *   - BLE removed (not needed for this demo)
 *
 * Node role is set at compile time in platformio.ini:
 *   Sender node:    -D SENDER_NODE -D DEVICE_ID=1 -D DESTINATION_ID=2
 *   Receiver node:  -D DEVICE_ID=2
 *
 * STM32-free mode:
 *   Add -D NO_STM32 to the sender's build_flags in platformio.ini.
 *   The sender generates a fake msgPayload instead of waiting for UART data.
 */

#include <Arduino.h>
#include <Wire.h>
#include "MeshNode.h"
#include "SensorManager.h"
#include "OLEDDisplay.h"

// How often the sender transmits (ms)
#define SEND_INTERVAL_MS 10000

MeshNode      meshNode(DEVICE_ID, NETWORK_ID);
SensorManager sensorManager;
OLEDDisplay   oledDisplay;

MeshNode*    g_MeshNode    = nullptr;
OLEDDisplay* g_OLEDDisplay = nullptr;

// ── msgPayload layout (matches STM32 __packed struct exactly) ───────────────
//   offset 0   : moduleID  (uint8)
//   offset 1   : row       (uint8)
//   offset 2-3 : hr        (uint16)
//   offset 4-5 : min       (uint16)
//   offset 6-7 : sec       (uint16)
//   offset 8-9 : gas       (uint16)
//   offset 10-13: temp     (float)
//   offset 14-17: hum      (float)
//   offset 18-21: volt     (float)
//   offset 22-213: pixels  (96 x uint16 = 192 bytes)
//   total = 214 bytes

/**
 * @brief Parses and pretty-prints a received 214-byte msgPayload.
 */
static void printMsgPayload(const uint8_t* buf, uint16_t src) {
    if (!buf) return;

    uint8_t  moduleID, row;
    uint16_t hr, mn, sec, gas;
    float    temp, hum, volt;

    memcpy(&moduleID, &buf[0],  1);
    memcpy(&row,      &buf[1],  1);
    memcpy(&hr,       &buf[2],  2);
    memcpy(&mn,       &buf[4],  2);
    memcpy(&sec,      &buf[6],  2);
    memcpy(&gas,      &buf[8],  2);
    memcpy(&temp,     &buf[10], 4);
    memcpy(&hum,      &buf[14], 4);
    memcpy(&volt,     &buf[18], 4);

    Serial.println("========================================");
    Serial.printf("  FROM NODE   : %u\n",            src);
    Serial.printf("  moduleID    : 0x%02X\n",        moduleID);
    Serial.printf("  row         : %u\n",             row);
    Serial.printf("  time (UTC)  : %02u:%02u:%02u\n", hr, mn, sec);
    Serial.printf("  gas (ADC)   : %u\n",             gas);
    Serial.printf("  temperature : %.2f C\n",         temp);
    Serial.printf("  humidity    : %.2f %%\n",        hum);
    Serial.printf("  voltage     : %.2f V\n",         volt);

    // First 8 pixels of the thermal frame slice
    Serial.print("  pixels[0-7] :");
    for (int i = 0; i < 8; i++) {
        uint16_t px;
        memcpy(&px, &buf[22 + i * 2], 2);
        Serial.printf(" %u", px);
    }
    Serial.println();
    Serial.println("========================================");
}

// ── Fake payload (NO_STM32 mode) ───────────────────────────────────────────
#ifdef NO_STM32
/**
 * @brief Fills buf with a fake msgPayload matching the real STM32 struct layout.
 * Values increment each call so you can see live changes in the serial monitor.
 */
static void makeFakePayload(uint8_t* buf) {
    static uint8_t counter = 0;
    counter++;

    memset(buf, 0, MSG_PAYLOAD_SIZE);

    // moduleID @ 0
    buf[0] = (uint8_t)DEVICE_ID;

    // row @ 1 (cycles 0-7 like the real STM32 does per frame)
    buf[1] = counter % 8;

    // hr, min, sec @ 2, 4, 6
    uint16_t hr = 12, mn = 0, sc = (uint16_t)((counter * 10) % 60);
    memcpy(&buf[2], &hr, 2);
    memcpy(&buf[4], &mn, 2);
    memcpy(&buf[6], &sc, 2);

    // gas ADC value @ 8
    uint16_t gas = 800 + (counter % 50) * 20;
    memcpy(&buf[8], &gas, 2);

    // temp (float) @ 10
    float temp = 24.5f + (counter % 20) * 0.1f;
    memcpy(&buf[10], &temp, 4);

    // hum (float) @ 14
    float hum = 55.0f + (counter % 10) * 0.5f;
    memcpy(&buf[14], &hum, 4);

    // volt (float) @ 18
    float volt = 3.5f;
    memcpy(&buf[18], &volt, 4);

    // pixels[96] @ 22 — fake hot-spot pattern
    for (int i = 0; i < 96; i++) {
        uint16_t px = 2800 + (i < 8 ? (8 - i) * 30 : 0) + (counter % 10) * 5;
        memcpy(&buf[22 + i * 2], &px, 2);
    }

    Serial.printf("DEBUG [NO_STM32] fake payload #%u generated\n", counter);
}
#endif // NO_STM32

// ── Setup ──────────────────────────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    delay(1000);
    Serial.println("\n\n========== WILDFIRE NODE SETUP ==========");
    Serial.printf("Device ID : %u\n", DEVICE_ID);
    Serial.printf("Network ID: %u\n", NETWORK_ID);
#ifdef SENDER_NODE
    Serial.printf("Role      : SENDER  (dest=%u)\n", DESTINATION_ID);
#else
    Serial.printf("Role      : RECEIVER / FORWARDER\n");
#endif

    g_MeshNode    = &meshNode;
    g_OLEDDisplay = &oledDisplay;

#ifdef NO_STM32
    Serial.println("Mode      : NO_STM32 (fake payload)");
#else
    sensorManager.begin();
#endif

    meshNode.begin();
    Serial.println("========== SETUP COMPLETE ==========\n");
}

// ── Loop ───────────────────────────────────────────────────────────────────
void loop() {
#ifndef NO_STM32
    sensorManager.update();
#endif

    meshNode.processReceivedQueue();
    meshNode.processRetransmissions();

    // Print any delivered payload
    if (meshNode.getLastPayloadLen() > 0) {
        const uint8_t* p   = meshNode.getLastPayload();
        uint16_t       len = meshNode.getLastPayloadLen();
        uint16_t       src = meshNode.getLastOriginalSenderID();

        Serial.printf("\n[RECEIVED] %u bytes from node %u\n", len, src);
        printMsgPayload(p, src);

        meshNode.clearLastPayload();
    }

#ifdef SENDER_NODE
    static uint32_t lastSendTime = 0;

    if (millis() - lastSendTime > SEND_INTERVAL_MS) {

#ifdef NO_STM32
        uint8_t payloadBuf[MSG_PAYLOAD_SIZE];
        makeFakePayload(payloadBuf);
        Serial.println("\n--- SENDING SENSOR PACKET (fake payload) ---");
        meshNode.sendSensorPacket(DESTINATION_ID, payloadBuf);
        lastSendTime = millis();

#else
        sensorManager.update();
        if (sensorManager.isDataReady()) {
            uint8_t payloadBuf[MSG_PAYLOAD_SIZE];
            size_t len = sensorManager.getPayload(payloadBuf, sizeof(payloadBuf));
            if (len == MSG_PAYLOAD_SIZE) {
                Serial.println("\n--- SENDING SENSOR PACKET (STM32 data) ---");
                meshNode.sendSensorPacket(DESTINATION_ID, payloadBuf);
                lastSendTime = millis();
            } else {
                Serial.println("WARN: getPayload returned unexpected size, skipping.");
            }
        } else {
            Serial.println("INFO: Waiting for STM32 payload...");
        }
#endif // NO_STM32

    }
#endif // SENDER_NODE
}
