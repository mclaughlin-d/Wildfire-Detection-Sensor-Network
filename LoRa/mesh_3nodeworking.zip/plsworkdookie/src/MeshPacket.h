#ifndef MESH_PACKET_H
#define MESH_PACKET_H

#include <Arduino.h>

/**
 * @enum PacketType
 * @brief Defines the type of the packet.
 */
enum PacketType : uint8_t {
    COORDINATION_PACKET,  // Regular mesh coordination (no sensor data)
    SENSOR_PACKET         // Contains sensor data payload (msgPayload struct)
};

/**
 * @class MeshPacket
 * @brief A serializable data structure for mesh network communication.
 *
 * Adapted from original 21-byte payload to support the wildfire detection
 * project's 214-byte msgPayload struct (thermal camera + sensor data).
 *
 * MAX_PAYLOAD is set to 220 to fit the 214-byte msgPayload with a few
 * bytes of headroom. Total PACKET_SIZE = 13 header bytes + 220 + 1 checksum = 234 bytes.
 * This is well within the SX1262's 255-byte LoRa payload limit.
 */
class MeshPacket {
public:
    // --- Header ---
    uint16_t originalSenderID;
    uint16_t senderID;
    uint16_t destinationID;
    uint16_t networkID;
    uint16_t packetID;
    PacketType packetType;

    // --- Payload ---
    static const size_t MAX_PAYLOAD = 220;  // fits 214-byte msgPayload
    uint8_t payloadLen;                     // actual used bytes (≤ MAX_PAYLOAD)
    uint8_t payload[MAX_PAYLOAD];

    // --- Footer ---
    uint8_t checksum;

    // Fixed serialized size. Must stay under 255 for SX1262 LoRa.
    // = 2+2+2+2+2+1+1+220+1 = 233 bytes
    static const size_t PACKET_SIZE =
        sizeof(originalSenderID) + sizeof(senderID) +
        sizeof(destinationID)   + sizeof(networkID) +
        sizeof(packetID)        + sizeof(packetType) +
        sizeof(payloadLen)      + MAX_PAYLOAD + sizeof(checksum);

    /**
     * @brief Default constructor.
     */
    MeshPacket()
        : originalSenderID(0), senderID(0), destinationID(0), networkID(0),
          packetID(0), packetType(COORDINATION_PACKET), payloadLen(0), checksum(0)
    {
        memset(payload, 0, MAX_PAYLOAD);
    }

    /**
     * @brief XOR checksum over all fields except the checksum byte itself.
     */
    uint8_t calculateChecksum() const {
        uint8_t chk = 0;
        // Header fields
        const uint8_t* p;
        p = (const uint8_t*)&originalSenderID; chk ^= p[0]; chk ^= p[1];
        p = (const uint8_t*)&senderID;         chk ^= p[0]; chk ^= p[1];
        p = (const uint8_t*)&destinationID;    chk ^= p[0]; chk ^= p[1];
        p = (const uint8_t*)&networkID;        chk ^= p[0]; chk ^= p[1];
        p = (const uint8_t*)&packetID;         chk ^= p[0]; chk ^= p[1];
        chk ^= (uint8_t)packetType;
        chk ^= payloadLen;
        // Payload (all MAX_PAYLOAD bytes, unused portion is zeroed)
        for (size_t i = 0; i < MAX_PAYLOAD; i++) chk ^= payload[i];
        return chk;
    }

    void updateChecksum() { checksum = calculateChecksum(); }

    /**
     * @brief Serialize into a flat byte buffer of exactly PACKET_SIZE bytes.
     */
    void serialize(uint8_t* buffer) const {
        size_t off = 0;
        memcpy(buffer + off, &originalSenderID, 2); off += 2;
        memcpy(buffer + off, &senderID,         2); off += 2;
        memcpy(buffer + off, &destinationID,    2); off += 2;
        memcpy(buffer + off, &networkID,        2); off += 2;
        memcpy(buffer + off, &packetID,         2); off += 2;
        buffer[off++] = (uint8_t)packetType;
        buffer[off++] = payloadLen;
        memcpy(buffer + off, payload, MAX_PAYLOAD); off += MAX_PAYLOAD;
        buffer[off]   = checksum;
    }

    /**
     * @brief Deserialize from a flat byte buffer. Returns true if checksum valid.
     */
    bool deserialize(const uint8_t* buffer) {
        size_t off = 0;
        memcpy(&originalSenderID, buffer + off, 2); off += 2;
        memcpy(&senderID,         buffer + off, 2); off += 2;
        memcpy(&destinationID,    buffer + off, 2); off += 2;
        memcpy(&networkID,        buffer + off, 2); off += 2;
        memcpy(&packetID,         buffer + off, 2); off += 2;
        packetType = (PacketType)buffer[off++];
        payloadLen = buffer[off++];
        memcpy(payload, buffer + off, MAX_PAYLOAD); off += MAX_PAYLOAD;
        uint8_t rxChecksum = buffer[off];

        if (rxChecksum == calculateChecksum()) {
            checksum = rxChecksum;
            return true;
        }
        return false;
    }
};

#endif // MESH_PACKET_H
