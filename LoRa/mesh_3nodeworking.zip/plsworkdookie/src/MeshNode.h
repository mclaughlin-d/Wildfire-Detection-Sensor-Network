/**
 * @file MeshNode.h
 * @brief LoRa mesh networking for RAK4631 — wildfire detection project.
 *
 * Adapted from prior group's codebase. Changes:
 *   - sendSensorPacket() payload size updated to MSG_PAYLOAD_SIZE (214 bytes)
 *   - _lastPayload buffer sized to MSG_PAYLOAD_SIZE
 *   - BLE dependency removed
 *   - OLEDDisplay dependency satisfied by stub header
 *   - Flooding mesh: every node rebroadcasts every unseen packet,
 *     enabling self-healing if any intermediate node goes down.
 */

#ifndef MESH_NODE_H
#define MESH_NODE_H

#include <Arduino.h>
#include <SX126x-Arduino.h>
#include "MeshPacket.h"
#include "OLEDDisplay.h"
#include "SensorManager.h"  // for MSG_PAYLOAD_SIZE

// How many recent packet IDs to remember for duplicate suppression.
// With a 10s send interval, 16 entries covers ~2.5 minutes of history.
#define SEEN_CACHE_SIZE 16

// --- Forward declarations for global radio callbacks ---
void OnTxDone(void);
void OnTxTimeout(void);
void OnRxDone(uint8_t *payload, uint16_t size, int16_t rssi, int8_t snr);
void OnRxTimeout(void);
void OnRxError(void);

extern OLEDDisplay* g_OLEDDisplay;

class MeshNode {
public:
    MeshNode(uint16_t deviceId, uint16_t networkId)
        : _deviceId(deviceId), _networkId(networkId),
          _packetCounter(0),
          _lastPayloadLen(0), _lastOriginalSenderID(0),
          _shouldRetransmit(false),
          _seenHead(0)
    {
        memset(_lastPayload, 0, sizeof(_lastPayload));
        memset(_seenPacketIDs, 0xFF, sizeof(_seenPacketIDs)); // 0xFFFF = empty
    }

    // ── Initialisation ──────────────────────────────────────────────────────
    void begin() {
        Serial.printf("INFO: Node %u starting on network %u.\n", _deviceId, _networkId);

        lora_rak4630_init();

        _radioEvents.TxDone    = OnTxDone;
        _radioEvents.TxTimeout = OnTxTimeout;
        _radioEvents.RxDone    = OnRxDone;
        _radioEvents.RxTimeout = OnRxTimeout;
        _radioEvents.RxError   = OnRxError;

        Radio.Init(&_radioEvents);
        Radio.SetChannel(915000000);
        Radio.SetTxConfig(MODEM_LORA, 22, 0, 0, 7, 1, 8, false, true, 0, 0, false, 500);
        Radio.SetRxConfig(MODEM_LORA, 0, 7, 1, 0, 8, 0, false, 0, true, 0, 0, false, true);

        startListening();
    }

    void startListening(bool verbose = true) {
        if (verbose) Serial.println("INFO: Listening.");
        Radio.Rx(0);
    }

    // ── Packet senders ──────────────────────────────────────────────────────

    void sendCoordinationPacket(uint16_t destinationId) {
        MeshPacket packet;
        packet.originalSenderID = _deviceId;
        packet.senderID         = _deviceId;
        packet.destinationID    = destinationId;
        packet.networkID        = _networkId;
        packet.packetID         = _packetCounter++;
        packet.packetType       = COORDINATION_PACKET;
        packet.payloadLen       = 0;
        packet.updateChecksum();

        // Mark our own packet as seen so we don't re-flood it if we hear it back
        markSeen(packet.packetID);

        uint8_t buffer[MeshPacket::PACKET_SIZE];
        packet.serialize(buffer);

        Serial.printf("INFO: Sending COORDINATION pkt %u -> dest %u\n",
                      packet.packetID, destinationId);
        Radio.Send(buffer, MeshPacket::PACKET_SIZE);
        if (g_OLEDDisplay) g_OLEDDisplay->showPacketSent(packet.packetID, destinationId);
    }

    void sendSensorPacket(uint16_t destinationId, const uint8_t* payload) {
        if (!payload) return;

        MeshPacket packet;
        packet.originalSenderID = _deviceId;
        packet.senderID         = _deviceId;
        packet.destinationID    = destinationId;
        packet.networkID        = _networkId;
        packet.packetID         = _packetCounter++;
        packet.packetType       = SENSOR_PACKET;
        packet.payloadLen       = MSG_PAYLOAD_SIZE;
        memcpy(packet.payload, payload, MSG_PAYLOAD_SIZE);
        packet.updateChecksum();

        // Mark our own packet as seen so we don't re-flood it
        markSeen(packet.packetID);

        uint8_t buffer[MeshPacket::PACKET_SIZE];
        packet.serialize(buffer);

        Serial.printf("INFO: Sending SENSOR pkt %u -> dest %u (%u bytes)\n",
                      packet.packetID, destinationId, MSG_PAYLOAD_SIZE);
        Radio.Send(buffer, MeshPacket::PACKET_SIZE);
        if (g_OLEDDisplay) g_OLEDDisplay->showPacketSent(packet.packetID, destinationId);
    }

    // ── Receive pipeline ────────────────────────────────────────────────────

    void queueReceivedPacket(uint8_t* payload, uint16_t size, int16_t rssi, int8_t snr) {
        if (size != MeshPacket::PACKET_SIZE) return;

        noInterrupts();
        uint8_t nextTail = (_rxQueueTail + 1) % RX_QUEUE_SIZE;
        if (nextTail == _rxQueueHead) {
            _rxQueueDropCount++;
            interrupts();
            return;
        }
        memcpy(_rxQueue[_rxQueueTail], payload, MeshPacket::PACKET_SIZE);
        _rxQueueRssi[_rxQueueTail] = rssi;
        _rxQueueSnr[_rxQueueTail]  = snr;
        _rxQueueTail = nextTail;
        interrupts();
    }

    void processReceivedQueue() {
        while (true) {
            noInterrupts();
            if (_rxQueueHead == _rxQueueTail) { interrupts(); break; }

            uint8_t buffer[MeshPacket::PACKET_SIZE];
            memcpy(buffer, _rxQueue[_rxQueueHead], MeshPacket::PACKET_SIZE);
            int16_t rssi = _rxQueueRssi[_rxQueueHead];
            int8_t  snr  = _rxQueueSnr[_rxQueueHead];
            _rxQueueHead = (_rxQueueHead + 1) % RX_QUEUE_SIZE;
            interrupts();

            handleReceivedPacket(buffer, MeshPacket::PACKET_SIZE, rssi, snr);
        }

        if (_rxQueueDropCount > 0) {
            Serial.printf("WARN: RX queue dropped %u packets\n", _rxQueueDropCount);
        }
    }

    void processRetransmissions() {
        if (!_shouldRetransmit) return;
        _shouldRetransmit = false;

        uint8_t buffer[MeshPacket::PACKET_SIZE];
        _retransmitPacket.serialize(buffer);
        Serial.printf("INFO: Flooding pkt %u (origSender=%u)\n",
                      _retransmitPacket.packetID, _retransmitPacket.originalSenderID);
        Radio.Send(buffer, MeshPacket::PACKET_SIZE);
    }

    // ── Accessors ───────────────────────────────────────────────────────────
    uint16_t       getDeviceId()             const { return _deviceId; }
    uint16_t       getNetworkId()            const { return _networkId; }
    const uint8_t* getLastPayload()          const { return _lastPayload; }
    uint16_t       getLastPayloadLen()       const { return _lastPayloadLen; }
    uint16_t       getLastOriginalSenderID() const { return _lastOriginalSenderID; }

    void clearLastPayload() {
        _lastPayloadLen = 0;
        memset(_lastPayload, 0, sizeof(_lastPayload));
    }

private:
    uint16_t      _deviceId;
    uint16_t      _networkId;
    uint32_t      _packetCounter;
    RadioEvents_t _radioEvents;

    // Last delivered payload
    uint8_t  _lastPayload[MSG_PAYLOAD_SIZE];
    uint16_t _lastPayloadLen;
    uint16_t _lastOriginalSenderID;

    // Deferred retransmit
    bool       _shouldRetransmit;
    MeshPacket _retransmitPacket;

    // ── Seen-packet cache (circular buffer of recent packet IDs) ────────────
    // Prevents a packet from being flooded more than once per node.
    uint16_t _seenPacketIDs[SEEN_CACHE_SIZE];
    uint8_t  _seenHead;  // next write position

    bool hasSeen(uint16_t packetID) const {
        for (uint8_t i = 0; i < SEEN_CACHE_SIZE; i++) {
            if (_seenPacketIDs[i] == packetID) return true;
        }
        return false;
    }

    void markSeen(uint16_t packetID) {
        _seenPacketIDs[_seenHead] = packetID;
        _seenHead = (_seenHead + 1) % SEEN_CACHE_SIZE;
    }

    // ISR-safe RX ring buffer
    static const uint8_t RX_QUEUE_SIZE = 16;
    volatile uint8_t _rxQueueHead = 0;
    volatile uint8_t _rxQueueTail = 0;
    uint8_t  _rxQueue[RX_QUEUE_SIZE][MeshPacket::PACKET_SIZE];
    int16_t  _rxQueueRssi[RX_QUEUE_SIZE];
    int8_t   _rxQueueSnr[RX_QUEUE_SIZE];
    volatile uint16_t _rxQueueDropCount = 0;

    // ── Core packet handler ─────────────────────────────────────────────────
    void handleReceivedPacket(uint8_t* raw, uint16_t size, int16_t rssi, int8_t snr) {
        Serial.println("\n--- PACKET RECEIVED ---");
        Serial.printf("RSSI: %d dBm  SNR: %d  Size: %u bytes\n", rssi, snr, size);

        if (size != MeshPacket::PACKET_SIZE) {
            Serial.printf("ERROR: Expected %u bytes, got %u. Discarding.\n",
                          MeshPacket::PACKET_SIZE, size);
            return;
        }

        MeshPacket packet;
        if (!packet.deserialize(raw)) {
            Serial.println("ERROR: Checksum INVALID. Discarding.");
            return;
        }

        Serial.println("INFO: Checksum OK.");
        Serial.printf("  origSender=%u  sender=%u  dest=%u  pktID=%u\n",
                      packet.originalSenderID, packet.senderID,
                      packet.destinationID, packet.packetID);

        // ── Duplicate suppression ───────────────────────────────────────────
        if (hasSeen(packet.packetID)) {
            Serial.println("INFO: Already seen this packet. Ignoring.");
            return;
        }
        markSeen(packet.packetID);

        // ── Deliver locally if addressed to us ─────────────────────────────
        if (packet.destinationID == _deviceId) {
            Serial.printf("INFO: Packet delivered. Type=%s  payloadLen=%u\n",
                          packet.packetType == SENSOR_PACKET ? "SENSOR" : "COORD",
                          packet.payloadLen);
            _lastOriginalSenderID = packet.originalSenderID;
            _lastPayloadLen       = packet.payloadLen;
            if (packet.payloadLen > 0 && packet.payloadLen <= MSG_PAYLOAD_SIZE) {
                memcpy(_lastPayload, packet.payload, packet.payloadLen);
            }
        }

        // ── Flood to neighbours regardless ─────────────────────────────────
        // This is what enables self-healing: even if we're the destination,
        // we rebroadcast so other nodes can overhear and the packet can reach
        // nodes that couldn't hear the original sender directly.
        // Sender nodes skip flooding their own transmissions (already markSeen'd).
        Serial.printf("INFO: Flooding pkt %u on behalf of node %u\n",
                      packet.packetID, packet.originalSenderID);
        retransmitPacket(packet);
    }

    void retransmitPacket(MeshPacket& packet) {
        packet.senderID = _deviceId;
        packet.updateChecksum();
        _retransmitPacket = packet;
        _shouldRetransmit = true;
    }
};

// ── Global pointers ─────────────────────────────────────────────────────────
extern MeshNode*    g_MeshNode;
extern OLEDDisplay* g_OLEDDisplay;

// ── Radio callbacks ──────────────────────────────────────────────────────────
inline void OnTxDone()    { if (g_MeshNode) g_MeshNode->startListening(false); }
inline void OnTxTimeout() { if (g_MeshNode) g_MeshNode->startListening(false); }
inline void OnRxTimeout() { if (g_MeshNode) g_MeshNode->startListening(false); }
inline void OnRxError()   { if (g_MeshNode) g_MeshNode->startListening(false); }

inline void OnRxDone(uint8_t* payload, uint16_t size, int16_t rssi, int8_t snr) {
    if (!g_MeshNode) return;
    g_MeshNode->queueReceivedPacket(payload, size, rssi, snr);
    g_MeshNode->startListening(false);
}

#endif // MESH_NODE_H
