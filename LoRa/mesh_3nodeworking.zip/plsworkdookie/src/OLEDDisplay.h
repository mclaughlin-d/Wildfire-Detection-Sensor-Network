#ifndef OLED_DISPLAY_H
#define OLED_DISPLAY_H

/**
 * @file OLEDDisplay.h
 * @brief No-op stub for OLEDDisplay.
 *
 * The original codebase had OLED support. This project does not use a display,
 * so all calls are stubbed to do nothing. This lets MeshNode.h and main.cpp
 * compile unchanged without touching every call site.
 */
class OLEDDisplay {
public:
    bool begin()                                                          { return true; }
    void update()                                                         {}
    void setSenderMode(bool)                                              {}
    void setSenderNodeInfo(uint16_t, uint8_t, uint8_t)                   {}
    void showPacketSent(uint16_t, uint16_t)                               {}
    void showPacketReceived(uint16_t, uint16_t, int16_t, int8_t,
                            uint8_t, uint8_t)                             {}
};

#endif // OLED_DISPLAY_H
